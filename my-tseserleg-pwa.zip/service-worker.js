const CACHE_NAME = 'app-cache-v1'; // Кэшийн хувилбар
const urlsToCache = [
  '/', // Энэ нь үндсэн URL-д хандана
  'index.html',
  'style.css',
  'app.js',
  'data.json',
  'manifest.json'
  // Нэмэлтээр icon-192.png, icon-512.png зэрэг зургийн файлуудыг нэмэх
];

self.addEventListener('install', e => {
  e.waitUntil(
    caches.open(CACHE_NAME).then(cache => {
        console.log('Service Worker: Кэшид файлууд нэмэгдсэн');
        return cache.addAll(urlsToCache);
    })
  );
});

self.addEventListener('fetch', e => {
  e.respondWith(
    caches.match(e.request).then(r => {
        // Хэрэв кэшид байгаа бол кэшийн хувилбарыг буцаана
        if (r) {
            return r;
        }
        // Кэшид байхгүй бол сүлжээнээс татна
        return fetch(e.request);
    })
  );
});

self.addEventListener('activate', e => {
    // Хуучин кэшүүдийг устгах
    const cacheWhitelist = [CACHE_NAME];
    e.waitUntil(
        caches.keys().then(cacheNames => {
            return Promise.all(
                cacheNames.map(cacheName => {
                    if (cacheWhitelist.indexOf(cacheName) === -1) {
                        return caches.delete(cacheName);
                    }
                })
            );
        })
    );
});