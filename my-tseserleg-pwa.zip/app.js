// Service Worker-ийг бүртгэх
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/service-worker.js')
      .then(reg => console.log('Service Worker: Бүртгэгдсэн'))
      .catch(err => console.error('Service Worker: Бүртгэл амжилтгүй', err));
  });
}

// Өгөгдөл унших
fetch('data.json')
.then(res => res.json())
.then(data => {
  const childrenList = document.getElementById('children-list');
  const teachersList = document.getElementById('teachers-list');
  const groupsList = document.getElementById('groups-list');
  const subjectsList = document.getElementById('subjects-list');

  // data.json-ийн мэдээллийг ашиглан жагсаалтыг үүсгэх
  data.groups.forEach(g => {
    const liGroup = document.createElement('li');
    liGroup.textContent = `${g.name} (${g.level}) - ${g.teacher}`;
    groupsList.appendChild(liGroup);
    
    // Багшийн жагсаалтад давхардахгүйгээр нэмэх (энэ хэсэгт таны өгсөн код бүх багшийг давхардуулан нэмж байсан тул засварлах шаардлагатай байж болно. Одоогоор зөвхөн анхны кодод үндэслэсэн.)
    const liTeacher = document.createElement('li');
    liTeacher.textContent = g.teacher;
    teachersList.appendChild(liTeacher);
    
    // Хүүхдийн жагсаалтад бүлгийн нэрийг нэмэх
    const liChild = document.createElement('li');
    liChild.textContent = g.name; // Энэ нь жинхэнэ хүүхдийн нэр биш, бүлгийн нэр байна.
    childrenList.appendChild(liChild);
  });

  data.subjects.forEach(s => {
    const liSubj = document.createElement('li');
    liSubj.textContent = s;
    subjectsList.appendChild(liSubj);
  });
});

// Media preview
document.getElementById('media-input').addEventListener('change', function(e){
  const preview = document.getElementById('media-preview');
  preview.innerHTML = '';
  Array.from(e.target.files).forEach(file => {
    if(file.type.startsWith('image/')){
      const img = document.createElement('img');
      img.src = URL.createObjectURL(file);
      img.className='media-preview';
      preview.appendChild(img);
    } else if(file.type.startsWith('video/')){
      const vid = document.createElement('video');
      vid.src = URL.createObjectURL(file);
      vid.controls = true;
      vid.className='media-preview';
      preview.appendChild(vid);
    } else if(file.type.startsWith('audio/')){
      const aud = document.createElement('audio');
      aud.src = URL.createObjectURL(file);
      aud.controls = true;
      aud.className='media-preview';
      preview.appendChild(aud);
    }
  });
});

function saveData(){
  // Энд формын мэдээллийг хадгалах (жишээ нь: LocalStorage, IndexedDB эсвэл серверт илгээх) код бичигдэнэ.
  alert("Мэдээлэл LocalStorage-д хадгалагдсан (туршилтын хувилбар)");
}